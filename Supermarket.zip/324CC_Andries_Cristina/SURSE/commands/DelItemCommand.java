package commands;

import departments.Department;
import interfaces.Command;
import store.Customer;
import store.Item;
import store.Store;

import java.util.ListIterator;

public class DelItemCommand implements Command {
    String[] op;

    public DelItemCommand(String[] op) {
        this.op = op;
    }

    @Override
    public void execute() {
        Item item = Store.getInstance().getItem(Integer.parseInt(op[1]));
        Customer customer = Store.getInstance().getCustomer(op[3]);
        Department department = item.getDepartment();


        if (op[2].equals("ShoppingCart")) {
            customer.getShoppingCart().removeItem(Integer.parseInt(op[1]));

        }
        if (op[2].equals("WishList")) {
            customer.getWishlist().removeItem(Integer.parseInt(op[1]));
        }

        department.remanageCustomer(customer);
    }
}
