package commands;

import interfaces.Command;
import store.Customer;
import store.Item;
import store.Store;

public class GetItemCommand implements Command {
    String[] op;

    public GetItemCommand(String[] op) {
        this.op = op;
    }

    @Override
    public void execute() {
        Customer customer = Store.getInstance().getCustomer(op[1]);

        Item item = customer.getWishlist().executeStrategy();

        customer.getShoppingCart().addItem(item);

        System.out.println(item);

        item.getDepartment().remanageCustomer(customer);

    }
}
