package commands;

import departments.Department;
import interfaces.Command;
import store.Customer;
import store.Item;
import store.Store;

public class GetItemsCommand implements Command {
    String[] op;

    public GetItemsCommand(String[] op) {
        this.op = op;
    }

    @Override
    public void execute() {
        Customer customer = Store.getInstance().getCustomer(op[2]);


        if (op[1].equals("ShoppingCart")) {
            System.out.println(customer.getShoppingCart());
        }
        if (op[1].equals("WishList")) {
            System.out.println(customer.getWishlist());
        }

    }
}
