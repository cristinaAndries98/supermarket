package commands;

import departments.Department;
import interfaces.Command;
import store.Customer;
import store.Item;
import store.Notification;
import store.Store;

public class DelProductCommand implements Command {
    String[] op;

    public DelProductCommand(String[] op) {
        this.op = op;
    }

    @Override
    public void execute() {
        Item item = Store.getInstance().getItem(Integer.parseInt(op[1]));
        Department department = item.getDepartment();

        department.getItems().remove(item);

        Notification notification = new Notification(Notification.TipNotificare.REMOVE, department.getId(), item.getId());
        department.notifyAllObserver(notification);

        for (Customer customer : Store.getInstance().getCustomers()) {
            department.remanageCustomer(customer);
        }

    }
}
