package commands;

import departments.Department;
import interfaces.Command;
import store.Customer;
import store.Item;
import store.Store;

public class AddItemCommand implements Command {
    String[] op;

    public AddItemCommand(String[] op) {
        this.op = op;
    }

    @Override
    public void execute() {
        Item item = Store.getInstance().getItem(Integer.parseInt(op[1]));
        Customer customer = Store.getInstance().getCustomer(op[3]);
        Department department = item.getDepartment();


        if (op[2].equals("ShoppingCart")) {
            customer.getShoppingCart().addItem(item);
            if (!department.getCustomers().contains(customer)) {
                department.enter(customer);
            }
        }
        if (op[2].equals("WishList")) {
            customer.getWishlist().add(item);

            if (!department.getCustomers().contains(customer)) {
                department.enter(customer);
            }

            if (!department.getObservers().contains(customer)) {
                department.addObserver(customer);
            }
        }
    }
}
