package commands;

import departments.Department;
import interfaces.Command;
import store.Item;
import store.Notification;
import store.Store;

public class ModifyCommand implements Command {
    String[] op;

    public ModifyCommand(String[] op) {
        this.op = op;
    }

    @Override
    public void execute() {
        Item item = Store.getInstance().getItem(Integer.parseInt(op[2]));
        Department department = Store.getInstance().getDepartment(Integer.parseInt(op[1]));

        item.setPrice(Double.parseDouble(op[3]));

        Notification notification = new Notification(Notification.TipNotificare.MODIFY, department.getId(), item.getId(),Double.parseDouble(op[3]));
        department.notifyAllObserver(notification);
    }
}
