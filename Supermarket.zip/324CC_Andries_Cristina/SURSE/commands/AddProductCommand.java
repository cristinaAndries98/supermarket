package commands;

import departments.Department;
import interfaces.Command;
import store.Item;
import store.Notification;
import store.Store;

public class AddProductCommand implements Command {
    String[] op;

    public AddProductCommand(String[] op) {
        this.op = op;
    }

    @Override
    public void execute() {
        Department department = Store.getInstance().getDepartment(Integer.parseInt(op[1]));
        Item item = new Item(op[4],Integer.parseInt(op[2]), Double.parseDouble(op[3]), department);

        department.addItem(item);

        Notification notification = new Notification(Notification.TipNotificare.ADD, Integer.parseInt(op[1]), Integer.parseInt(op[2]));

        department.notifyAllObserver(notification);
    }
}
