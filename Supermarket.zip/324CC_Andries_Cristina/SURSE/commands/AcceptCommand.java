package commands;

import departments.Department;
import interfaces.Command;
import store.Customer;
import store.Store;

public class AcceptCommand implements Command {
    String[] op;

    public AcceptCommand(String[] op) {
        this.op = op;
    }

    @Override
    public void execute() {
        Department department = Store.getInstance().getDepartment(Integer.parseInt(op[1]));
        Customer customer = Store.getInstance().getCustomer(op[2]);

        department.accept(customer.getShoppingCart());

    }
}
