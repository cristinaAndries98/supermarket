package commands;

import interfaces.Command;
import store.Customer;
import store.Notification;
import store.Store;

public class GetNotificationsCommand implements Command {
    String[] op;

    public GetNotificationsCommand(String[] op) {
        this.op = op;
    }

    @Override
    public void execute() {
        Customer customer = Store.getInstance().getCustomer(op[1]);

        System.out.println(customer.getNotifications());
    }
}
