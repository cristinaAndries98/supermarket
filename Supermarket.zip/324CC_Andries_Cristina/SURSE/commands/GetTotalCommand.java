package commands;

import interfaces.Command;
import store.Customer;
import store.Store;

public class GetTotalCommand implements Command {
    String[] op;

    public GetTotalCommand(String[] op) {
        this.op = op;
    }

    @Override
    public void execute() {
        Customer customer = Store.getInstance().getCustomer(op[2]);

        if (op[1].equals("ShoppingCart")) {
            System.out.println(customer.getShoppingCart().getTotalPrice());
        }
        if (op[1].equals("WishList")) {
            System.out.println(customer.getWishlist().getTotalPrice());
        }
    }
}
