package commands;

import departments.Department;
import interfaces.Command;
import interfaces.Observer;
import store.Customer;
import store.Store;

public class GetObserversCommand implements Command {
    String[] op;

    public GetObserversCommand(String[] op) {
        this.op = op;
    }

    @Override
    public void execute() {
        Department department = Store.getInstance().getDepartment(Integer.parseInt(op[1]));

        System.out.print("[");

        for (int i = 0; i < department.getObservers().size(); i++) {
            System.out.print(((Customer)department.getObservers().get(i)).getName());
            if (i < department.getObservers().size() - 1) {
                System.out.print(", ");
            }
        }

        System.out.println("]");
    }
}
