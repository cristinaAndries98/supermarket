import interfaces.Command;
import utils.InputParser;

import java.util.LinkedList;

public class Test {

    public static void main(String[] args) {
        InputParser.getInstance().storeInputParse("/home/cristina/Desktop/324CC_Andries_Cristina/SURSE/test03/store.txt");
        InputParser.getInstance().customersInputParser("/home/cristina/Desktop/324CC_Andries_Cristina/SURSE/test03/customers.txt");

        LinkedList<Command> commands;
        commands = InputParser.getInstance().commandsInputParser("/home/cristina/Desktop/324CC_Andries_Cristina/SURSE/test03/events.txt");

        for (Command command : commands) {
            command.execute();
        }
    }
}
