package strategy;

import interfaces.Strategy;
import store.Item;
import store.ItemList;
import store.WishList;

import java.util.Comparator;
import java.util.ListIterator;

public class StrategyB implements Strategy {	//primul produs alfabetic
    @Override
    public Item execute(WishList wishList) {
        ItemList<Item> items = new ItemList<Item>(new Comparator<Item>() {
            @Override
            public int compare(Item o1, Item o2) {	//comparator pentru nume
                return o1.getName().compareTo(o2.getName());
            }
        }) {
            @Override
            public Double getTotalPrice() {
                return null;
            }
        };

        ListIterator<Item> it = wishList.listIterator();
        while (it.hasNext()) {
            Item item = it.next();	//pun in lista items elementele din wishList in ordine alfabetica
            items.add(item);
        }

        Item item = items.getItem(0);	//fac remove la primul element, care e primul alfabetic
        wishList.remove(item);			//si il returnez
        return item;
    }
}