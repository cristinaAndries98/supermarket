package strategy;

import interfaces.Strategy;
import store.Item;
import store.WishList;

public class StrategyC implements Strategy {
    @Override
    public Item execute(WishList wishList) {	//cel mai recent produs din WishList
        Item item = wishList.remove(wishList.getSize() - 1);	//cel mai recent e ultimul adaugat
        return item;
    }
}
