package strategy;

import interfaces.Strategy;
import store.Item;
import store.WishList;

import java.util.ListIterator;

public class StrategyA implements Strategy {
    @Override
    public Item execute(WishList wishList) {	//returneaza produsul cel mai ieftin
        Item cheapest = null;
        double min = Double.MAX_VALUE;

        ListIterator<Item> it = wishList.listIterator();
        while (it.hasNext()) {	//parcurg lista si gasesc minimumul
            Item item = it.next();
            if (item.getPrice() < min) {
                min = item.getPrice();
                cheapest = item;
            }
        }

        wishList.remove(cheapest);	//sterg din WishList 
        return cheapest;
    }
}
