package store;
import departments.Department;
public class Item {
	private String name; 
	private int ID;
	private double pret;
	private Department department;
	
	public Item(String name, int ID, double pret, Department department) {
		this.name = name;
		this.ID = ID; 
		this.pret = pret;
		this.department = department;
	}

	public Department getDepartment() {
		return department;
	}

	public void setDepartment(Department department) {
		this.department = department;
	}

	public String toString() {
		 return this.name+";"+this.ID+";"+String.format("%.2f",pret);
	}

	public double getPrice() {
		return pret;
	}
	
	public void setPrice(double pret) {
		this.pret = pret;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public int getId() {
		return ID;
	}
	
	public void setId(int ID) {
		this.ID = ID;
	}
}
