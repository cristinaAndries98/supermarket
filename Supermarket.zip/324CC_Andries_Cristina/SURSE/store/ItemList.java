package store;
import java.util.*;
public abstract class ItemList<Item> {
    private Node<Item> head = null;
    private Node<Item> tail = null;
    private int size = 0;
    private Comparator<Item> itemComparator = null;

    public ItemList(Comparator<Item> itemComparator) {
        this.itemComparator = itemComparator;
    }

    public static class Node<Item> {//clasa interna Node
        private Node<Item> next = null;
        private Node<Item> prev = null;
        private Item info;

        public Node() {	//constructor
            this(null);
        }

        public Node(Item info) {	//constructor
            this.info = info;
        }

        public Node(Item info, Node<Item> next, Node<Item> prev) { //constructor
            this.next = next;
            this.prev = prev;
            this.info = info;
        }

        public void setInfo(Item info) {
            this.info = info;
        }

        public void setPrev(Node<Item> prev) {
            this.prev = prev;
        }

        public void setNext(Node<Item> next) {
            this.next = next;
        }

        public Item getInfo() {
            return info;
        }

        public Node<Item> getNext() {
            return next;
        }

        public Node<Item> getPrev(){
            return prev;
        }
    }

    public class ItemIterator implements ListIterator<Item> {
        private Node<Item> nodCurent;
        private Node<Item> nodPrev;
        private int index;

        public ItemIterator() {	//constructor
            nodCurent = head;
            nodPrev = null;
        }

        @Override
        public boolean hasNext() {
            return nodCurent != null;
        }

        @Override
        public Item next() {
            if (!hasNext())  throw new NoSuchElementException();
            Item data = nodCurent.info;
            nodPrev = nodCurent;
            nodCurent = nodCurent.next;
            index++;
            return data;
        }

        @Override
        public boolean hasPrevious() {
            return nodCurent != null || nodCurent.prev != null;
        }

        @Override
        public Item previous() {
            if (!hasPrevious())  throw new NoSuchElementException();
            nodCurent = nodCurent.prev;
            nodPrev = nodCurent;
            index--;
            return nodCurent.info;
        }

        @Override
        public int nextIndex() {
            return index;
        }

        @Override
        public int previousIndex() {
            return index - 1;
        }

        @Override
        public void remove() {
            if (nodPrev == null) throw new IllegalStateException(); //lista vida
            size--;

            if (nodPrev.prev == null && nodPrev.next == null) {	
                head = tail = null;
                return;
            }

            if (nodPrev.prev != null) {	
                nodPrev.prev.next = nodPrev.next;
            } else {
                head = head.next;
            }

            if (nodPrev.next != null) {
                nodPrev.next.prev = nodPrev.prev;
            } else {
                tail = tail.prev;
            }
        }

        @Override
        public void set(Item item) {
            if (nodPrev == null) throw new IllegalStateException();
            nodPrev.setInfo(item);
        }

        
        @Override
        public void add(Item item) {
            Node<Item> nou = new Node<>(item, null, null);
            size++;

            if (head == null) {	
                head = tail = nou;
                nodPrev = nou;
                return;
            }

            if (nodPrev == null) {
                nou.setNext(head);
                head = nou;
                nodPrev = nou;
                return;
            }

            if (nodPrev.next == null) {
                nou.setPrev(tail);
                tail = nou;
                nodPrev = nou;
                return;
            }

            nou.setNext(nodPrev.next);
            nou.setPrev(nodPrev);
            nodPrev.next.setPrev(nou);
            nodPrev.setNext(nou);
        }
    }

    public boolean add(Item element) {
        size++;

        if (head == null) {
            head = tail = new Node<Item>(element, null, null);
            return true;
        }

        Node<Item> node = head;
        Node<Item> nou = new Node<>(element, null, null);

        if (itemComparator.compare(element, node.info) <= 0) {
            nou.setNext(head);
            head = nou;
            return true;
        }

        while (node != tail && itemComparator.compare(element, node.next.info) > 0) {
            node = node.next;
        }

        nou.setNext(node.next);
        nou.setPrev(node);

        if (node != tail) {
            node.next.setPrev(nou);
        } else {
            tail = nou;
        }

        node.setNext(nou);

        return true;
    }

    public boolean addAll(Collection<? extends Item> c) {
        for (Item item : c) {
            boolean added = add(item);
            if (added == false) {
                return false;
            }
        }

        return true;
    }

    public Item getItem(int index) {
        if (index >= size)  throw new IndexOutOfBoundsException();

        ListIterator<Item> it = this.listIterator();
        Item item = null;
        for (int i = 0; i <= index; i++) {
            item = it.next();
        }

        return item;
    }

    public Node<Item> getNode(int index) {
        if (index >= size)   throw new IndexOutOfBoundsException();

        Node<Item> node = head;

        for (int i = 0; i < index; i++) {
            node = node.next;
        }

        return node;
    }

    public int indexOf(Item item) {
        ListIterator<Item> it = this.listIterator();
        int index = 0;
        while (it.hasNext()) {
            Item listItem = it.next();
            if (listItem.equals(item)) {
                return index;
            }
            index++;
        }

        return -1;
    }

    public int indexOf(Node<Item> newNode) {
        Node<Item> node = head;
        int index = 0;
        while (node != null) {
            if (node.equals(newNode)) {
                return index;
            }
            node = node.next;
        }
        return -1;
    }

    public boolean contains(Node<Item> newNode) {
        Node<Item> node = head;
        while (node != null) {
            if (node.equals(newNode)) {
                return true;
            }
            node = node.next;
        }
        return false;
    }

    public boolean contains(Item item) {
        ListIterator<Item> it = this.listIterator();
        while (it.hasNext()) {
            Item listItem = it.next();
            if (listItem.equals(item)) {
                return true;
            }
        }
        return false;
    }

    public Item remove(int index) {
        if (index >= size)   throw new IndexOutOfBoundsException();
        ListIterator<Item> it = this.listIterator();
        int i = 0;
        while (it.hasNext()) {
            Item listItem = it.next();
            if (i == index) {
                it.remove();
                return listItem;
            }
            i++;
        }

        return null;

    }

    public boolean remove(Item item) {
        if (remove(indexOf(item)) == null) {
            return false;
        }
        return true;
    }

    public boolean removeAll(Collection<? extends Item> collection) {
        for (Item item : collection) {
            if (!remove(item)) {
                return false;
            }
        }
        return true;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public ListIterator<Item> listIterator(int index) {
        return null;
    }

    public ListIterator<Item> listIterator() {
        return new ItemIterator();
    }

    public abstract Double getTotalPrice();

    public void setSize(int size) {
        this.size = size;
    }

    @Override
    public String toString() {
        String s = "[";

        ListIterator<Item> it = this.listIterator();
        while (it.hasNext()) {
            Item item = it.next();
            s += item.toString();

            if (it.hasNext()) {
                s += ", ";
            }
        }
        s += "]";
        return s;
    }

    public Node<Item> getHead() {
        return head;
    }

    public void setHead(Node<Item> head) {
        this.head = head;
    }

    public Node<Item> getTail() {
        return tail;
    }

    public void setTail(Node<Item> tail) {
        this.tail = tail;
    }

    public int getSize() {
        return size;
    }
}
