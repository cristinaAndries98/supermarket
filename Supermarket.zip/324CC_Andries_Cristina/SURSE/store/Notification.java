package store;

import java.util.Date;

public class Notification {
	public Date data = new Date();			//data la care e trimisa notificarea
	public static enum TipNotificare {		//enumerare cu tipurile de notificari
		ADD, REMOVE, MODIFY
	}
	public TipNotificare tipNotificare;
	public int IdDepartament;				//ID departament
	public int IdProdus;					//Id produs;
	public double priceModify;
	
	public Notification(TipNotificare tipNotificare, int IdDepartament, int IdProdus) {	//constuctor
		this.tipNotificare = tipNotificare;
		this.IdDepartament = IdDepartament;
		this.IdProdus = IdProdus;
	}

	public Notification(TipNotificare tipNotificare, int IdDepartament, int IdProdus, double priceModify) {	//constructor
		this.tipNotificare = tipNotificare;
		this.IdDepartament = IdDepartament;
		this.IdProdus = IdProdus;
		this.priceModify = priceModify;
	}
	
	public TipNotificare getTipNotificare() {
		return tipNotificare;
	}
	
    public String toString()
    {
        return tipNotificare.toString() + ";" + IdProdus + ";" + IdDepartament;
    }
}
