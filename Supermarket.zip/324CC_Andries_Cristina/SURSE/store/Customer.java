package store;
import interfaces.Strategy;
import store.Notification;
import interfaces.Observer;
import store.ShoppingCart;
import store.WishList;
import java.util.LinkedList;
import java.util.ListIterator;
public class Customer implements Observer {
    private String name;			//numele clientului
    public ShoppingCart object;	    //obiectul de tip store.ShoppingCart
    private WishList obj;			//obiectul de tip store.WishList
    private LinkedList<Notification> notifications = new LinkedList<Notification>(); //Colectia de notificari
     
    public Customer(String name, double budget, Strategy strategy) {
    	this.name = name;
    	object = new ShoppingCart(budget);  	
    	obj = new WishList(strategy);
    }
    
    public String toString() {
    	return name;
    }
    
	public WishList getWishlist() {
		return obj;
	}

	public ShoppingCart getShoppingCart() {
		return object;
	}
	
	public LinkedList<Notification> getNotifications() {
		return notifications;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	@Override
	public void update(Notification notification) {
		notifications.add(notification);			//adaug notificarea la colectia de notificari

		if(notification.getTipNotificare().equals(Notification.TipNotificare.REMOVE)) {
			object.removeAllItems(notification.IdProdus);
			obj.removeAllItems(notification.IdProdus);
		}
		
		if(notification.getTipNotificare().equals(Notification.TipNotificare.MODIFY)) {
			object.modifyPrice(notification.IdProdus, notification.priceModify);
			obj.modifyPrice(notification.IdProdus, notification.priceModify);
		}
			
	}
}
