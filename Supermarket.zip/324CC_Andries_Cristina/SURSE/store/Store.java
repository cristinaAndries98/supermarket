package store;
import departments.Department;
import java.util.LinkedList;
public class Store {
	public String numeStore;													//numele magazinului
	public LinkedList<Department> departments = new LinkedList<Department>();	//lista de departamente
	public LinkedList<Customer> customers = new LinkedList<Customer>(); ;		//lista de clienti	
	private static Store instance = null;  										//mentinem o referinta catre un magazin store.Store in mai multe clase
	
	//folosim Singleton pattern deci constructorul(unul) va fi privat
	private Store() {	
		
	}
	
	//metoda prin care se creeaza unica instanta a clasei
    public static Store getInstance() {
        if (instance == null)
            instance = new Store(); 
        return instance;
    }
    
	//daca a intrat in magazin fac add la lista
	public void enter(Customer customer) { 
		customers.add(customer);
	}
	
	//daca a iesit din magazin fac remove la lista
	public void exit(Customer customer) { 
		customers.remove(customer);
	}	
	
	//returnez un store.ShoppingCart nou cu parametru bugetul
	public ShoppingCart getShoppingCart(Double buget) {
        return new ShoppingCart(buget);
    }
	
	//returnez toti clientii
	public LinkedList<Customer> getCustomers() {
		return customers;
	}
	
	//returnez toate departamentele
	public LinkedList<Department> getDepartments(){
		return departments;
	}
	
	//adaug un departament nou la lista
	public void addDepartment(Department depNou) {
		departments.add(depNou);
	}
	
	//caut dupa ID si returnez departamentul
	public Department getDepartment(Integer ID) {
		for(Department obj : departments) 
			if(obj.getId() == ID) 
				return obj;
			return null;
	}

	//caut dupa ID si returnez itemul
	public Item getItem(int id) {
		for (Department department : departments) {
			for (Item item : department.getItems()) {
				if (item.getId() == id) {
					return item;
				}
			}
		}
		return null;
	}

	//caut dupa nume si returnez clientul
	public Customer getCustomer(String name) {
		for (Customer customer : customers) {
			if (customer.getName().equals(name)) {
				return customer;
			}
		}
		return null;
	}
}


