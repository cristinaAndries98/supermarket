package store;
import departments.BookDepartment;
import departments.MusicDepartment;
import departments.SoftwareDepartment;
import departments.VideoDepartment;
import interfaces.Visitor;
import utils.ItemComparator;

import java.util.ListIterator;

public class ShoppingCart extends ItemList<Item> implements Visitor {
    public double buget;	//are un buget

    public ShoppingCart(double buget) {
        super(new ItemComparator());
    	this.buget = buget;
    }

    public boolean addItem(Item item) {
    	if (buget < item.getPrice())
			return false;

    	boolean added = super.add(item);
    	if (!added)
    		return false;

    	buget = buget - item.getPrice();
    	return true;
	}

	public Item removeItem(int itemId) {
		ListIterator<Item> iterator = this.listIterator();
		while (iterator.hasNext()) {
			Item item = iterator.next();
			if (item.getId() == itemId) {
				iterator.remove();
				buget = buget + item.getPrice();
				return item;
			}
		}
		return null;
	}

	public void removeAllItems(int itemId) {
		ListIterator<Item> iterator = this.listIterator();
		while (iterator.hasNext()) {
			Item item = iterator.next();
			if (item.getId() == itemId) {
				iterator.remove();
				buget = buget + item.getPrice();
			}
		}
	}

	public void modifyPrice(int itemId, double priceModify) {
		ListIterator<Item> iterator = this.listIterator();
		while(iterator.hasNext()) {
			Item item = iterator.next();
			if(item.getId() == itemId) {
				buget = buget + item.getPrice() - priceModify;
				item.setPrice(priceModify);
			}
		}
	}

    public void setBudget(double buget) {
    	this.buget = buget;
    }
    
    public double getBudget() {
    	return buget;
    }

	@Override
	public Double getTotalPrice() {
    	Double total = 0.0;
		ListIterator<Item> it = this.listIterator();
		while (it.hasNext()) {
			Item item = it.next();
			total += item.getPrice();
		}

		return total;
	}

	@Override
	public void visit(BookDepartment bookDepartment) {//-10% din pret produs din store.ShoppingCart
		   ListIterator<Item> iterator = this.listIterator();
			while (iterator.hasNext()) {
				Item item = iterator.next();
				if (bookDepartment.getItems().contains(item)) {
					double pretVechi = item.getPrice();
					double pretNou = Math.round(0.9 * pretVechi * 100.0) / 100.0;
					item.setPrice(pretNou);
				}
			}	
	}

	@Override
	public void visit(MusicDepartment musicDepartment) {//+10% la produsele din musicDep din ShopCart
		   ListIterator<Item> iterator = this.listIterator();
		   double pretProduse = 0;
		   while(iterator.hasNext())  {
		   	Item item = iterator.next();
			   if(musicDepartment.getItems().contains(item))
				   pretProduse = pretProduse + item.getPrice();
		   }
			this.buget = this.buget + Math.round(pretProduse*0.1 * 100.0) / 100.0;
	}

	@Override
	public void visit(SoftwareDepartment softwareDepartment) {

    		for (Item item : softwareDepartment.getItems()) {	//daca pretul depaseste bugetul atunci fac exit
    			if (buget >= item.getPrice())
    				return;
			}

			ListIterator<Item> iterator = this.listIterator();
			while (iterator.hasNext()) {
				Item item = iterator.next();
				if (softwareDepartment.getItems().contains(item)) {
					double pretVechi = item.getPrice();
					double pretNou = Math.round(0.8 * pretVechi * 100.0) / 100.0;
					item.setPrice(pretNou);
				}
			}
	}

	@Override
	public void visit(VideoDepartment videoDepartment) {
			ListIterator<Item> iterator = this.listIterator();
			double pretProduse = 0;
			while(iterator.hasNext())  {	//fac suma totala pt pret produse
				Item item = iterator.next();
				if(videoDepartment.getItems().contains(item))
					pretProduse = pretProduse + item.getPrice();
			}
			this.buget = this.buget + Math.round(pretProduse*0.05 * 100.0) / 100.0;

			double maxPrice = 0;	//aflu pretul maxim
			for (Item item : videoDepartment.getItems()) {
				if (item.getPrice() > maxPrice) {
					maxPrice = item.getPrice();
				}
			}

			if (pretProduse >= maxPrice) {	//daca pretul tuturor produselor e mai mare decat pretul maxim fac modificare
				iterator = this.listIterator();
				while(iterator.hasNext())  {
					Item item = iterator.next();
					if(videoDepartment.getItems().contains(item)) {
						double pretVechi = item.getPrice();
						double pretNou = Math.round(0.15 * pretVechi * 100.0) / 100.0;
						item.setPrice(pretNou);
					}

				}
			}
	}


}