package store;
import interfaces.Strategy;
import utils.ItemComparator;
import java.util.ListIterator;
public class WishList extends ItemList<Item> {
	public Strategy strategy;

	public WishList(Strategy s) {
		super(new ItemComparator());	//itemComparator: sorteaza dupa pret 
		strategy = s;					//in caz de egalitate, sorteaza dupa nume
	}

	public boolean add(Item element) {
		setSize(getSize() + 1);

		if (getHead() == null) {
			Node<Item> node = new Node<Item>(element, null, null);
			setHead(node);
			setTail(node);
			return true;
		}

		Node<Item> nou = new Node<>(element, null, getTail());

		getTail().setNext(nou);
		setTail(nou);

		return true;
	}

	public Item removeItem(int itemId) {
		ListIterator<Item> iterator = this.listIterator();
		while (iterator.hasNext()) {
			Item item = iterator.next();
			if (item.getId() == itemId) {
				iterator.remove();
				return item;
			}
		}
		return null;
	}

	public void removeAllItems(int itemId) {
		ListIterator<Item> iterator = this.listIterator();
		while (iterator.hasNext()) {
			Item item = iterator.next();
			if (item.getId() == itemId) {
				iterator.remove();
			}
		}
	}

	public void modifyPrice(int itemId, double priceModify) {
		ListIterator<Item> iterator = this.listIterator();
		while(iterator.hasNext()) {
			Item item = iterator.next();
			if(item.getId() == itemId) {
				item.setPrice(priceModify);
			}
		}
	}

	@Override
	public Double getTotalPrice() {
		Double total = 0.0;
		ListIterator<Item> it = this.listIterator();
		while (it.hasNext()) {
			Item item = it.next();
			total += item.getPrice();
		}

		return total;
	}

	public Item executeStrategy() {
		return strategy.execute(this);
	}
}
