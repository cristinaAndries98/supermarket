package utils;

import departments.*;

public class DepartmentFactory {
    private static DepartmentFactory instance;

    private DepartmentFactory() { }

    public static DepartmentFactory getInstance() {
        if (instance == null) {
            instance = new DepartmentFactory();
        }
        return instance;
    }

    public Department getDepartment(String type, int id) {
        switch (type) {
            case "BookDepartment":
                return new BookDepartment(type, id);
            case "MusicDepartment":
                return new MusicDepartment(type, id);
            case "SoftwareDepartment":
                return new SoftwareDepartment(type, id);
            case "VideoDepartment":
                return new VideoDepartment(type, id);
            default:
                return null;
        }
    }
}
