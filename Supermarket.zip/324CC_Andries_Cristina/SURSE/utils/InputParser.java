package utils;

import commands.*;
import departments.Department;
import interfaces.Command;
import interfaces.Strategy;
import store.Customer;
import store.Item;
import store.Store;
import strategy.StrategyA;
import strategy.StrategyB;
import strategy.StrategyC;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.LinkedList;

public class InputParser {
    private static InputParser instance = null;

    private InputParser() { }

    public static InputParser getInstance() {
        if (instance == null) {
            instance = new InputParser();
        }
        return instance;
    }

    public void storeInputParse(String filename) {

        try(BufferedReader in = new BufferedReader(new FileReader(filename))) {
            String str = null;

            Store.getInstance().numeStore = in.readLine();

            while ((str = in.readLine()) != null) {
                String[] tokens = str.split(";");

                Department department = DepartmentFactory.getInstance().getDepartment(tokens[0], Integer.parseInt(tokens[1]));

                str = in.readLine();
                int itemsNr = Integer.parseInt(str);
                for (int i = 0; i < itemsNr; i++) {
                    str = in.readLine();
                    tokens = str.split(";");

                    department.addItem(new Item(tokens[0], Integer.parseInt(tokens[1]), Double.parseDouble(tokens[2]), department));
                }

                Store.getInstance().addDepartment(department);
            }
        }
        catch (IOException e) {
            System.out.println("File Read Error");
        }
    }

    public void customersInputParser(String filename) {
        try(BufferedReader in = new BufferedReader(new FileReader(filename))) {
            String str;

            int customersNr = Integer.parseInt(in.readLine());

            for (int i = 0; i < customersNr; i++) {
                str = in.readLine();
                String[] tokens = str.split(";");

                Strategy strategy;
                switch (tokens[2]) {
                    case "A":
                        strategy = new StrategyA();
                        break;
                    case "B":
                        strategy = new StrategyB();
                        break;
                    case "C":
                        strategy = new StrategyC();
                        break;
                    default:
                        strategy = null;
                }

                Store.getInstance().enter(new Customer(tokens[0], Double.parseDouble(tokens[1]), strategy));
            }
        }
        catch (IOException e) {
            System.out.println("File Read Error");
        }
    }

    public LinkedList<Command> commandsInputParser(String filename) {
        try(BufferedReader in = new BufferedReader(new FileReader(filename))) {
            String str = null;
            LinkedList<Command> commands = new LinkedList<>();
            int commandsNr = Integer.parseInt(in.readLine());

            for (int i = 0; i < commandsNr; i++) {
                str = in.readLine();
                String[] tokens = str.split(";");

                switch (tokens[0]) {
                    case "addItem":
                        commands.add(new AddItemCommand(tokens));
                        break;
                    case "delItem":
                        commands.add(new DelItemCommand(tokens));
                        break;
                    case "addProduct":
                        commands.add(new AddProductCommand(tokens));
                        break;
                    case "modifyProduct":
                        commands.add(new ModifyCommand(tokens));
                        break;
                    case "delProduct":
                        commands.add(new DelProductCommand(tokens));
                        break;
                    case "getItem":
                        commands.add(new GetItemCommand(tokens));
                        break;
                    case "getItems":
                        commands.add(new GetItemsCommand(tokens));
                        break;
                    case "getTotal":
                        commands.add(new GetTotalCommand(tokens));
                        break;
                    case "accept":
                        commands.add(new AcceptCommand(tokens));
                        break;
                    case "getObservers":
                        commands.add(new GetObserversCommand(tokens));
                        break;
                    case "getNotifications":
                        commands.add(new GetNotificationsCommand(tokens));
                        break;
                    default:
                        throw new IOException();
                }
            }

            return commands;
        }
        catch (IOException e) {
            System.out.println("File Read Error");
        }

        return null;

    }
}
