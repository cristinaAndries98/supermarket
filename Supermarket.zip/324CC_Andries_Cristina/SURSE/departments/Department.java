package departments;
import interfaces.Observer;
import interfaces.Subject;
import store.Customer;
import store.Item;
import store.Notification;
import store.ShoppingCart;
import java.util.LinkedList;
import java.util.ListIterator;
public abstract class Department implements Subject {
	//folosesc interfaces.Observer in cadrul careia departments.Department este interfaces.Subject care are o lista de observers
	private String name;														//nume departament
	private LinkedList<Item> itemuri = new LinkedList<Item>();					//lista cu item-uri
	private LinkedList<Customer> listaClienti1 = new LinkedList<Customer>(); 	//lista cu clienti cu minimum un obj cumparat
	private LinkedList<Observer> observers = new LinkedList<Observer>();		//lista de observeri
	private int ID;
	
	public Department(String name, int ID) {
		this.name = name; 
		this.ID = ID;
	}
	
	public void enter(Customer customer) {
		listaClienti1.add(customer);
	}
	
	public void exit(Customer customer) {
		listaClienti1.remove(customer);
	}
	
	public LinkedList<Customer> getCustomers() {
		return listaClienti1;
	}
	
	public int getId() {
		return ID; 
	}

	public void addItem(Item object) {
		itemuri.add(object);
	}
	
	public LinkedList<Item> getItems(){
		return itemuri;
	}
	
    public String toString() {
    	return name + " " + ID;
    }
    
    //adaug un observer
	public void addObserver(Observer observer) {
		if(!observers.contains(observer))
			observers.add(observer);
	}

	//sterg un observer
	public void removeObserver(Observer observer) {
		observers.remove(observer);
	}

	//parcurg toti observatorii si le trimit notificarea
	public void notifyAllObserver(Notification notification) {
		for(Observer cust:observers) {
			cust.update(notification);	
		}
	}
	
	public abstract void accept(ShoppingCart shoppingCart);

	public LinkedList<Observer> getObservers() {
		return observers;
	}

	public void remanageCustomer(Customer customer) {	//folosita la comezi, verifici daca clientul mai are produse din departament in wishList si daca nu
		ListIterator<Item> it = customer.getWishlist().listIterator();	//nu mai are produse, atunci il sterge
		while (it.hasNext()) {
			Item listItem = it.next();
			if (listItem.getDepartment().equals(this)) {
				return;
			}
		}

		removeObserver(customer);

		it = customer.getShoppingCart().listIterator();
		while (it.hasNext()) {
			Item listItem = it.next();
			if (listItem.getDepartment().equals(this)) {
				return;
			}
		}

		exit(customer);
	}
}
