package departments;

import store.ShoppingCart;

public class MusicDepartment extends Department {

	public MusicDepartment(String name, int ID) {
		super(name, ID);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void accept(ShoppingCart shoppingCart) {
		shoppingCart.visit(this);
	}

}
