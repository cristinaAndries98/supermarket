package departments;

import store.ShoppingCart;

public class SoftwareDepartment extends Department {

	public SoftwareDepartment(String name, int ID) {
		super(name, ID);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void accept(ShoppingCart shoppingCart) {
		shoppingCart.visit(this);		
	}

}
