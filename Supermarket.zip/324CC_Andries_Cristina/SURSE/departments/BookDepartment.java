package departments;

import store.ShoppingCart;

public class BookDepartment extends Department {

	public BookDepartment(String name, int ID) {
		super(name, ID);
	}

	@Override
	public void accept(ShoppingCart shoppingCart) {
		shoppingCart.visit(this);
	}
}
