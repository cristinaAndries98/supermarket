package interfaces;

public interface Command {

    void execute();
}
