package interfaces;

import store.Item;
import store.WishList;

public interface Strategy {
    public Item execute(WishList wishList);
}
