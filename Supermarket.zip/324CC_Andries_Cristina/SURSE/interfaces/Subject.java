package interfaces;

public interface Subject {

}
