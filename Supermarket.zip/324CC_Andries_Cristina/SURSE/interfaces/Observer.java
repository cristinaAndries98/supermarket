package interfaces;

import store.Notification;

public interface Observer {
	public void update(Notification notification);
}
